exports.handler = async function(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const GROQ_API_KEY = process.env.GROQ_API_KEY;
  
  if (!GROQ_API_KEY) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "GROQ_API_KEY غير موجود" })
    };
  }

  try {
    const body = JSON.parse(event.body);
    const { image, mimeType, high, low, current, open, close } = body;

    const candleType = (open && close) ? (close > open ? "صاعدة" : close < open ? "هابطة" : "دوجي") : "غير محدد";

    const prompt = `أنت محلل تقني متخصص في أسواق الأسهم.
بناءً على البيانات التالية:
- أعلى قمة: ${high}
- أدنى قاع: ${low}
- السعر الحالي: ${current}
${open ? `- افتتاح آخر شمعة: ${open}` : ''}
${close ? `- إغلاق آخر شمعة: ${close}` : ''}
${candleType !== "غير محدد" ? `- نوع الشمعة: ${candleType}` : ''}

أجب فقط بـ JSON صحيح بدون أي نص إضافي أو backticks:
{"trend":"صاعد","trend_strength":"قوي","macd":{"signal":"صاعد","note":"وصف"},"ichimoku":{"signal":"صاعد","above_cloud":true,"note":"وصف"},"atr_fibo":{"atr_value":"5.2","volatility":"متوسط","note":"وصف"},"silver_hidden_gap":{"exists":true,"direction":"صاعد","level":"4.5","note":"وصف"},"support_resistance":{"signal":"صاعد","note":"وصف"},"candle_pattern":{"signal":"صاعد","pattern":"Pin Bar","note":"وصف"},"volume":{"signal":"صاعد","note":"وصف"},"momentum":{"signal":"صاعد","note":"وصف"},"analysis":"تحليل تفصيلي هنا"}`;

    const content = image ? [
      { type: "image_url", image_url: { url: `data:${mimeType || 'image/jpeg'};base64,${image}` } },
      { type: "text", text: prompt }
    ] : prompt;

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${GROQ_API_KEY}`
      },
      body: JSON.stringify({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        max_tokens: 1500,
        temperature: 0.3,
        messages: [{ role: "user", content }]
      })
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error?.message || `Groq error: ${response.status}`);
    }

    const raw = data.choices?.[0]?.message?.content || "";
    // استخراج JSON من الرد
    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("لم يتم إرجاع JSON صحيح");
    
    const result = JSON.parse(jsonMatch[0]);

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify(result)
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: err.message })
    };
  }
};
